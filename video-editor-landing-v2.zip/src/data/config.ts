// ============================================================
// CONFIGURACIÓN PRINCIPAL — editá aquí sin tocar el código
// ============================================================

export const SITE = {
  name: "Tu Nombre",           // <-- REEMPLAZAR
  title: "Editor de Reels & TikToks",
  description: "Edito videos cortos para Instagram y TikTok. Resultados que hacen parar el scroll.",
  url: "https://tunombre.com", // <-- REEMPLAZAR
};

export const CONTACT = {
  whatsapp: "+5493804367406",
  whatsappMessage: "Hola 👋 quiero contratar tu servicio",
  instagram: "@tunombre",      // <-- REEMPLAZAR
  instagramUrl: "https://instagram.com/tunombre", // <-- REEMPLAZAR
};

// WhatsApp URL generada automáticamente
export const WA_URL = `https://wa.me/${CONTACT.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(CONTACT.whatsappMessage)}`;

// ============================================================
// VIDEOS DEL CARRUSEL — agregá o quitá items aquí
// ============================================================

export const VIDEOS = [
  {
    id: 1,
    src: "/videos/reel-01.mp4",         // <-- REEMPLAZAR con tu video
    poster: "/videos/reel-01-poster.jpg", // <-- REEMPLAZAR con imagen de portada
    title: "Reel dinámico",
  },
  {
    id: 2,
    src: "/videos/reel-02.mp4",         // <-- REEMPLAZAR
    poster: "/videos/reel-02-poster.jpg", // <-- REEMPLAZAR
    title: "Storytelling",
  },
  {
    id: 3,
    src: "/videos/reel-03.mp4",         // <-- REEMPLAZAR
    poster: "/videos/reel-03-poster.jpg", // <-- REEMPLAZAR
    title: "Edición para creador",
  },
  {
    id: 4,
    src: "/videos/reel-04.mp4",         // <-- REEMPLAZAR
    poster: "/videos/reel-04-poster.jpg", // <-- REEMPLAZAR
    title: "Montaje emocional",
  },
  {
    id: 5,
    src: "/videos/reel-05.mp4",         // <-- REEMPLAZAR
    poster: "/videos/reel-05-poster.jpg", // <-- REEMPLAZAR
    title: "Corte rítmico",
  },
];

// ============================================================
// VIDEO DEL HERO — video vertical de muestra
// ============================================================

export const HERO_VIDEO = {
  src: "/videos/hero.mp4",         // <-- REEMPLAZAR
  poster: "/videos/hero-poster.jpg", // <-- REEMPLAZAR
};
